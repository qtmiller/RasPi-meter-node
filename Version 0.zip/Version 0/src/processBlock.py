

from block import Block

class ProcessBlock(Block):

    def __init__(self):
        super().__init__()
        return None

    def load_last_rec_value(self, tag_point):
        return 0

    
