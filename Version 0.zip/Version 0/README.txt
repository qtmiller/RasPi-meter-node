Raspberry Pi Meter Node

Project goal:
	Enable a Raspberry Pi to be used as a general purpose data logger.

Authors:
	Quinn Miller - Energy Engineer